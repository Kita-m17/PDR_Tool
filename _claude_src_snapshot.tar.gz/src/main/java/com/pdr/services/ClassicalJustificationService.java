package com.pdr.services;

import com.pdr.models.HittingSetTree;
import com.pdr.models.KnowledgeBase;
import com.pdr.models.Node;
import com.pdr.models.PartitionStep;
import com.pdr.utils.Utils;
import org.tweetyproject.logics.pl.reasoner.SatReasoner;
import org.tweetyproject.logics.pl.sat.Sat4jSolver;
import org.tweetyproject.logics.pl.sat.SatSolver;
import org.tweetyproject.logics.pl.syntax.PlBeliefSet;
import org.tweetyproject.logics.pl.syntax.PlFormula;
import org.tweetyproject.logics.pl.syntax.Proposition;

import java.util.*;

/**
 *
 * @author stevewang
 */
public class ClassicalJustificationService
{
    public static List<KnowledgeBase> computeJustification(PlBeliefSet knowledgeBase, PlFormula query)
    {
        return computeJustification(knowledgeBase, query, null);
    }

    /**
     * Same algorithm as {@link #computeJustification(PlBeliefSet, PlFormula)}: expand each
     * candidate support by relevance (signature overlap), contract it down to a minimal support,
     * then walk the Reiter hitting-set-tree rooted at that first justification to enumerate every
     * minimal justification for {@code query} in {@code knowledgeBase}.
     * <p>
     * When {@code traceSteps} is non-null, one {@link PartitionStep} is appended per
     * hitting-set-tree node visited (root first, then each child in BFS order), exposing the same
     * kind of information {@code PartitionUsingPowersetImpl} exposes for its powerset search, but
     * for this expand/contract search instead:
     * <ul>
     *     <li>{@code set} - the expand set computed for that node (the relevance-driven candidate
     *     support before minimisation)</li>
     *     <li>{@code minimalSet} - the contract set: the justification found for that node (empty
     *     if the expand set didn't entail the query, so there was nothing to contract)</li>
     *     <li>{@code isEntailed} - whether that node produced a non-empty justification</li>
     *     <li>{@code isMinimal} - whether that justification is newly found, i.e. not already
     *     present in the running list (mirrors the superset/duplicate check
     *     PartitionUsingPowersetImpl runs against its own {@code resList})</li>
     *     <li>{@code justificationsSoFar} - every distinct justification found by this node or an
     *     earlier one, in discovery order</li>
     * </ul>
     *
     * @param traceSteps optional list to append per-node trace steps to; pass {@code null} to
     *                    skip trace collection - the original two-argument overload does this and
     *                    behaves exactly as before
     */
    public static List<KnowledgeBase> computeJustification(PlBeliefSet knowledgeBase, PlFormula query, List<PartitionStep> traceSteps)
    {
        SatSolver.setDefaultSolver(new Sat4jSolver());
        SatReasoner reasoner = new SatReasoner();

        List<KnowledgeBase> justificationsSoFar = new ArrayList<>();
        int[] stepId = { 1 };

        // Construct root node
        SingleJustificationResult rootResult = computeSingleJustification(knowledgeBase, query, reasoner);
        recordStep(traceSteps, stepId, rootResult, justificationsSoFar);

        Node rootNode = new Node(knowledgeBase, rootResult.justification());

        // Create a queue to keep track of nodes
        Queue<Node> queue = new LinkedList<Node>();
        queue.add(rootNode);
        HittingSetTree tree = new HittingSetTree(rootNode);

        while(!queue.isEmpty())
        {
            Node node = queue.poll();

            for( PlFormula formula : node.getJustification())
            {
                PlBeliefSet childKnowledgeBase = Utils.remove(node.getKnowledgeBase(), formula);
                SingleJustificationResult childResult = computeSingleJustification(childKnowledgeBase, query, reasoner);
                recordStep(traceSteps, stepId, childResult, justificationsSoFar);

                Node childNode = new Node(childKnowledgeBase, childResult.justification());

                node.addChildNode(formula, childNode);
                tree.addNode(childNode);

                if (childResult.justification() != null || childResult.justification().isEmpty())
                {
                    queue.add(childNode);
                }
            }
        }

        //System.out.println("Tree:");
        //System.out.println(rootNode.toString());

        List<List<PlFormula>> justifications = rootNode.getAllJustifications();


        List<KnowledgeBase> allJustifications = new ArrayList<>();
        for (List<PlFormula> justification : justifications) {
            KnowledgeBase just = new KnowledgeBase();
            just.addAll(justification);
            allJustifications.add(just);


        }
        return allJustifications;
    }

    /**
     * Bundles the intermediate expand set (the relevance-driven candidate support) together with
     * the contract set it minimised down to (the justification, possibly empty), so both survive
     * long enough to be exposed on a trace step - {@link #computeSingleJustification} used to
     * return only the contract set, silently discarding the expand set.
     */
    private record SingleJustificationResult(List<PlFormula> expandSet, List<PlFormula> justification) {}

    /**
     * Appends one {@link PartitionStep} to {@code traceSteps} (a no-op if it's null) describing
     * one hitting-set-tree node: its expand set, its contract set/justification, whether that
     * justification is newly-found, and the running list of distinct justifications found so far.
     * {@code justificationsSoFar} is mutated in place, growing by one whenever this node's
     * justification is non-empty and not already present (compared by content, order-independent,
     * via {@link Utils#compareFormulaList}).
     */
    private static void recordStep(List<PartitionStep> traceSteps, int[] stepId, SingleJustificationResult result, List<KnowledgeBase> justificationsSoFar)
    {
        if (traceSteps == null)
            return;

        KnowledgeBase expandSet = new KnowledgeBase(result.expandSet());
        KnowledgeBase contractSet = new KnowledgeBase(result.justification());
        boolean isEntailed = !result.justification().isEmpty();
        boolean isMinimal = false;
        String reason;

        if (isEntailed)
        {
            boolean alreadyFound = false;
            for (KnowledgeBase existing : justificationsSoFar)
            {
                if (Utils.compareFormulaList(new ArrayList<>(existing), result.justification()))
                {
                    alreadyFound = true;
                    break;
                }
            }
            if (!alreadyFound)
            {
                isMinimal = true;
                justificationsSoFar.add(new KnowledgeBase(contractSet));
                reason = "Expand set entails the query; contracted to a new minimal justification.";
            }
            else
            {
                reason = "Expand set entails the query, but contracted to a justification already found.";
            }
        }
        else
        {
            reason = "Expand set does not entail the query - no justification at this node.";
        }

        traceSteps.add(PartitionStep.builder()
                .withId(stepId[0])
                .withSet(expandSet)
                .withMinimalSet(contractSet)
                .withIsEntailed(isEntailed)
                .withIsMinimal(isMinimal)
                .withReason(reason)
                .withJustificationsSoFar(new ArrayList<>(justificationsSoFar))
                .build());

        stepId[0]++;
    }

    private static SingleJustificationResult computeSingleJustification(PlBeliefSet knowledgeBase, PlFormula query, SatReasoner reasoner)
    {
        if (knowledgeBase.contains(query))
        {
            List<PlFormula> trivial = new ArrayList<PlFormula>();
            trivial.add(query);
            return new SingleJustificationResult(new ArrayList<PlFormula>(trivial), trivial);
        }

        List<PlFormula> expand = expandFormulas(knowledgeBase, query, reasoner);
        if (expand.isEmpty())
            return new SingleJustificationResult(expand, new ArrayList<PlFormula>());

        List<PlFormula> contract = contractFormuls(expand, query, reasoner);

        return new SingleJustificationResult(expand, contract);
    }

    private static void printResultJustification(List<PlFormula> result)
    {
        System.out.println("Print result justification");
        Utils.print(result);
    }

    private static List<PlFormula> expandFormulas(PlBeliefSet knowledgeBase, PlFormula query, SatReasoner reasoner)
    {
        List<PlFormula> result = new ArrayList<PlFormula>();

        if (!reasoner.query(knowledgeBase, query))
            return new ArrayList<PlFormula>();
        else
        {
            List<PlFormula> sPrime = new ArrayList<PlFormula>();
            List<Proposition> sigma = getSignature(query);
            while (result != sPrime)
            {
                sPrime = result;
                result = Utils.union(result, findRelatedFormulas(sigma, knowledgeBase));
                PlBeliefSet resultKownledgeBase = new PlBeliefSet(result);
                if (reasoner.query(resultKownledgeBase, query))
                    return result;
                sigma = getSignature(result);
            }
        }
        return result;
    }

    private static List<PlFormula> findRelatedFormulas(List<Proposition> signatures, PlBeliefSet knowledgeBase)
    {
        List<PlFormula> result = new ArrayList<PlFormula>();

        for(PlFormula formula: knowledgeBase)
        {
            if (!Collections.disjoint(getSignature(formula), signatures))
                result.add(formula);
        }

        return result;
    }

    private static List<Proposition> getSignature(List<PlFormula> formulas)
    {
        List<Proposition> result = new ArrayList<Proposition>();
        for (PlFormula formula: formulas)
        {
            List<Proposition> signature = getSignature(formula);
            for (Proposition atom : signature)
            {
                if (!result.contains(atom))
                    result.add(atom);
            }
        }
        return result;
    }

    private static List<Proposition> getSignature(PlFormula query)
    {
        List<Proposition> result = new ArrayList<Proposition>();
        Set<Proposition> atoms = query.getAtoms();
        result.addAll(atoms);
        return result;
    }

    private static List<PlFormula> contractFormuls(List<PlFormula> result, PlFormula query, SatReasoner reasoner)
    {
        return contractRecursive(new ArrayList<PlFormula>(), result, query, reasoner);
    }

    private static List<PlFormula> contractRecursive(List<PlFormula> support, List<PlFormula> whole, PlFormula query, SatReasoner reasoner)
    {
        if (whole.size() == 1)
            return whole;

        List<List<PlFormula>> splitList = split(whole);
        List<PlFormula> left = splitList.get(0);
        List<PlFormula> right = splitList.get(1);

        List<PlFormula> leftUnion = Utils.union(support, left);
        PlBeliefSet leftKB = new PlBeliefSet(leftUnion);
        List<PlFormula> rightUnion = Utils.union(support, right);
        PlBeliefSet rightKB = new PlBeliefSet(rightUnion);

        if (reasoner.query(leftKB, query))
            return contractRecursive(support, left, query, reasoner);
        if (reasoner.query(rightKB, query))
            return contractRecursive(support, right, query, reasoner);

        List<PlFormula> leftPrime = contractRecursive(rightUnion, left, query, reasoner);
        List<PlFormula> leftPrimeUnion = Utils.union(support, leftPrime);
        List<PlFormula> rightPrime = contractRecursive(leftPrimeUnion, right, query, reasoner);

        return Utils.union(leftPrime, rightPrime);
    }

    private static List<List<PlFormula>> split(List<PlFormula> whole)
    {
        List<PlFormula> left = whole.subList(0, whole.size()/2);
        List<PlFormula> right = whole.subList(whole.size()/2, whole.size());

        List<List<PlFormula>> result = new ArrayList<>();
        result.add(left);
        result.add(right);

        return result;
    }

}
