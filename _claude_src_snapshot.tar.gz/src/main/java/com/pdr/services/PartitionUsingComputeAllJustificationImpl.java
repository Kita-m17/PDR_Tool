package com.pdr.services;
/*
 * Original Author: Liam De Saldanha , Honours Project (2026), University of Cape Town
 *
 * Context: Used in PDR project for relevant closure reasoning.
 * Purpose: Educational use only.
 */
import com.pdr.models.*;
import com.pdr.utils.Utils;
import org.tweetyproject.logics.pl.sat.Sat4jSolver;
import org.tweetyproject.logics.pl.sat.SatSolver;
import org.tweetyproject.logics.pl.syntax.Implication;
import org.tweetyproject.logics.pl.syntax.Negation;
import org.tweetyproject.logics.pl.syntax.PlFormula;

import java.util.ArrayList;
import java.util.List;

/**
 * Alternative to {@link PartitionUsingPowersetImpl} that reuses
 * {@link ClassicalJustificationService#computeJustification} - Steve Wang's expand/contract +
 * Reiter hitting-set-tree justification engine - instead of enumerating the powerset of the
 * ampliative (defeasible) part of the knowledge base.
 * <p>
 * Both implementations answer the same question: which epsilon-justifications for the negated
 * query antecedent are subset-minimal (what PartitionUsingPowersetImpl finds by brute-force
 * combination checking), and - for minimal relevant closure - which lowest-base-rank slice of
 * each one to keep (Def. 3.30). This implementation finds the same minimal justifications
 * directly, via relevance-driven expansion + contraction instead of exhaustive powerset
 * enumeration, so for the same knowledgeBase/query/isMinimalRelevantClosure it is intended to
 * produce the same relevantPartition, irrelevantPartition, classicalStatements and knowledgeBase
 * as PartitionUsingPowersetImpl (see PartitionUsingComputeAllJustificationImplTest, which checks
 * both implementations against the same fixtures).
 * <p>
 * The trace exposes, for every node visited by the hitting-set-tree search: the expand set
 * ({@code set}), the contract set / justification found at that node ({@code minimalSet}),
 * whether it was entailed and newly-minimal, and the running list of distinct justifications
 * found so far ({@code justificationsSoFar}) - the same {@link PartitionStep} shape
 * PartitionUsingPowersetImpl's trace uses, so both traces can be displayed/compared the same way.
 */
public class PartitionUsingComputeAllJustificationImpl implements PartitionService {

    private Partition partition;

    @Override
    public Partition getPartition(KnowledgeBase knowledgeBase, PlFormula query, boolean isMinimalRelevantClosure) {
        long startTime = System.nanoTime();

        SatSolver.setDefaultSolver(new Sat4jSolver());

        KnowledgeBase classicalKnowledgeBase = knowledgeBase.separate()[1];
        KnowledgeBase materialisedKnowledgeBase = knowledgeBase.materialisedKnowledgeBase();
        List<PlFormula> classicalFormulasList = new ArrayList<>(classicalKnowledgeBase);

        // Same test PartitionUsingPowersetImpl runs against every powerset combination: find the
        // minimal sets that entail the negation of the query's antecedent - the ~alpha
        // epsilon-justifications that make the antecedent exceptional (Def. 3.29).
        PlFormula negatedAntecedent = new Negation(((Implication) query).getFirstFormula());

        List<PartitionStep> traceSteps = new ArrayList<>();
        List<KnowledgeBase> rawJustifications = ClassicalJustificationService.computeJustification(
                materialisedKnowledgeBase, negatedAntecedent, traceSteps);

        // computeJustification works over the materialised knowledge base (defeasible
        // implications standing in as plain classical implications), so translate each
        // justification's formulas back into the original knowledge base's own defeasible/
        // classical objects before comparing or combining them with knowledgeBase /
        // classicalKnowledgeBase below.
        List<KnowledgeBase> justifications = new ArrayList<>();
        for (KnowledgeBase rawJustification : rawJustifications) {
            List<PlFormula> dematerialised = Utils.dematerialise(new ArrayList<>(rawJustification), classicalFormulasList);
            justifications.add(new KnowledgeBase(dematerialised));
        }

        BaseRank baseRank = new BaseRankServiceImp().constructBaseRank(knowledgeBase);

        List<KnowledgeBase> resList = new ArrayList<>();
        for (KnowledgeBase justification : justifications) {
            // Same superset guard PartitionUsingPowersetImpl runs against its own resList: a
            // justification that's a superset of one already kept contributes nothing new.
            boolean minimal = true;
            for (KnowledgeBase existing : resList) {
                if (justification.containsAll(existing)) {
                    minimal = false;
                    break;
                }
            }
            if (!minimal) {
                continue;
            }

            if (isMinimalRelevantClosure) {
                resList.add(lowestRankSlice(justification, baseRank));
            } else {
                resList.add(justification);
            }
        }

        KnowledgeBase relevantString = new KnowledgeBase();
        for (KnowledgeBase kb : resList) {
            relevantString = relevantString.union(kb);
        }
        relevantString = relevantString.difference(classicalKnowledgeBase);
        KnowledgeBase irrelevantString = new KnowledgeBase(knowledgeBase);
        irrelevantString = irrelevantString.difference(relevantString);

        long endTime = System.nanoTime();
        double durationSeconds = (double) (endTime - startTime) / 1_000_000_000.0;

        this.partition = Partition.builder()
                .withIrrelevantPartition(irrelevantString)
                .withRelevantPartition(relevantString)
                .withTraceSteps(traceSteps)
                .withExecutionTime(durationSeconds)
                .withClassicalStatements(classicalKnowledgeBase)
                .withKnowledgeBase(knowledgeBase)
                .build();
        return this.partition;
    }

    @Override
    public Partition getInstance() {
        return partition;
    }

    /**
     * Mirrors PartitionUsingPowersetImpl's per-combination reduction for minimal relevant
     * closure: keep only the formulas of {@code justification} that sit in its lowest occupied
     * base rank (the most normal, least exceptional part of the justification).
     */
    private static KnowledgeBase lowestRankSlice(KnowledgeBase justification, BaseRank baseRank) {
        KnowledgeBase minimalJustificationStatement = new KnowledgeBase();
        int lowestRank = Integer.MAX_VALUE;
        for (Rank rank : baseRank.getRanking()) {
            for (PlFormula pl : justification) {
                if (rank.getFormulas().contains(pl) && rank.getRankNumber() < lowestRank) {
                    lowestRank = rank.getRankNumber();
                    minimalJustificationStatement.add(pl);
                }
            }
        }
        return minimalJustificationStatement;
    }
}
