package com.pdr.services;
/*
 * Original Author: Liam De Saldanha , Honours Project (2026), University of Cape Town
 *
 * Context: Used in PDR project for testing partition service.
 * Purpose: Educational use only.
 */
import com.pdr.models.BaseRank;
import com.pdr.models.KnowledgeBase;
import com.pdr.models.Partition;
import com.pdr.models.PartitionStep;
import com.pdr.utils.DefeasibleParser;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.tweetyproject.logics.pl.syntax.PlFormula;

import java.util.List;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;

/**
 * Checks that PartitionUsingComputeAllJustificationImpl - the expand/contract + hitting-set-tree
 * justification search - returns the same relevantPartition/irrelevantPartition/
 * classicalStatements/knowledgeBase as PartitionUsingPowersetImpl's brute-force powerset search,
 * for the same fixtures PartitionUsingPowersetImplTest already checks. It also checks that the
 * trace this implementation produces exposes an expand set and a contract set (the two things
 * PartitionUsingPowersetImpl's own trace has no equivalent of) alongside the running list of
 * justifications found so far.
 */
class PartitionUsingComputeAllJustificationImplTest {
    private final DefeasibleParser parser = new DefeasibleParser();

    private static KnowledgeBaseService fixedKbService(KnowledgeBase knowledgeBase, BaseRank baseRank) {
        return new KnowledgeBaseService() {
            public KnowledgeBase getKnowledgeBase() { return knowledgeBase; }
            public BaseRank getBaseRank() { return baseRank; }
            public void setKnowledgeBase(KnowledgeBase newKb) {}
        };
    }

    @Test
    @DisplayName("Minimal relevant partition matches PartitionUsingPowersetImpl for {(bird|~flies),(bird|~wings),(penguin=>bird),(penguin|~!flies)} / query (penguin|~!flies)")
    void getMinimalPartitionExample1MatchesPowerset() throws Exception {
        KnowledgeBase knowledgeBase = parser.parseFormulas("(bird|~flies),(bird|~wings),(penguin=>bird),(penguin|~!flies)");
        PlFormula query = parser.parseFormula("(penguin|~!flies)");
        boolean isMinimalRelevantClosure = true;
        BaseRank baseRank = new BaseRankServiceImp().constructBaseRank(knowledgeBase);

        Partition powersetPartition = new PartitionUsingPowersetImpl(fixedKbService(knowledgeBase, baseRank))
                .getPartition(knowledgeBase, query, isMinimalRelevantClosure);

        PartitionService justificationPartitionService = new PartitionUsingComputeAllJustificationImpl();
        Partition justificationPartition = justificationPartitionService.getPartition(knowledgeBase, query, isMinimalRelevantClosure);

        assertThat(justificationPartition.getRelevantPartition())
                .containsExactlyInAnyOrderElementsOf(powersetPartition.getRelevantPartition());
        assertThat(justificationPartition.getIrrelevantPartition())
                .containsExactlyInAnyOrderElementsOf(powersetPartition.getIrrelevantPartition());
        assertThat(justificationPartition.getClassicalStatements())
                .containsExactlyInAnyOrderElementsOf(powersetPartition.getClassicalStatements());
        assertThat(justificationPartition.getKnowledgeBase())
                .containsExactlyInAnyOrderElementsOf(powersetPartition.getKnowledgeBase());

        // Also pinned to the exact fixture values PartitionUsingPowersetImplTest checks.
        assertThat(justificationPartition.getRelevantPartition()).containsExactlyInAnyOrder(
                parser.parseFormula("(bird|~flies)")
        );
        assertThat(justificationPartition.getIrrelevantPartition()).containsExactlyInAnyOrder(
                parser.parseFormula("(penguin|~!flies)"),
                parser.parseFormula("(bird|~wings)"),
                parser.parseFormula("(penguin=>bird)")
        );

        assertExposesExpandContractAndJustifications(justificationPartition);
    }

    @Test
    @DisplayName("Basic relevant partition matches PartitionUsingPowersetImpl for {(bird|~flies),(bird|~wings),(penguin=>bird),(penguin|~!flies)} / query (penguin|~!flies)")
    void getBasicPartitionExample1MatchesPowerset() throws Exception {
        KnowledgeBase knowledgeBase = parser.parseFormulas("(bird|~flies),(bird|~wings),(penguin=>bird),(penguin|~!flies)");
        PlFormula query = parser.parseFormula("(penguin|~!flies)");
        boolean isMinimalRelevantClosure = false;
        BaseRank baseRank = new BaseRankServiceImp().constructBaseRank(knowledgeBase);

        Partition powersetPartition = new PartitionUsingPowersetImpl(fixedKbService(knowledgeBase, baseRank))
                .getPartition(knowledgeBase, query, isMinimalRelevantClosure);

        PartitionService justificationPartitionService = new PartitionUsingComputeAllJustificationImpl();
        Partition justificationPartition = justificationPartitionService.getPartition(knowledgeBase, query, isMinimalRelevantClosure);

        assertThat(justificationPartition.getRelevantPartition())
                .containsExactlyInAnyOrderElementsOf(powersetPartition.getRelevantPartition());
        assertThat(justificationPartition.getIrrelevantPartition())
                .containsExactlyInAnyOrderElementsOf(powersetPartition.getIrrelevantPartition());

        assertThat(justificationPartition.getRelevantPartition()).containsExactlyInAnyOrder(
                parser.parseFormula("(penguin|~!flies)"),
                parser.parseFormula("(bird|~flies)")
        );
        assertThat(justificationPartition.getIrrelevantPartition()).containsExactlyInAnyOrder(
                parser.parseFormula("(bird|~wings)"),
                parser.parseFormula("(penguin=>bird)")
        );

        assertExposesExpandContractAndJustifications(justificationPartition);
    }

    @Test
    @DisplayName("Minimal relevant partition matches PartitionUsingPowersetImpl for the kittens/cats/animals example")
    void getMinimalPartitionExample2MatchesPowerset() throws Exception {
        KnowledgeBase knowledgeBase = parser.parseFormulas("(pets=>animals),(kittens=>cats), (cats|~trainable), (kittens|~!trainable), (animals|~legs), (animals|~wild), (cats=>animals), (cats|~!wild)");
        PlFormula query = parser.parseFormula("(kittens|~!wild)");
        boolean isMinimalRelevantClosure = true;
        BaseRank baseRank = new BaseRankServiceImp().constructBaseRank(knowledgeBase);

        Partition powersetPartition = new PartitionUsingPowersetImpl(fixedKbService(knowledgeBase, baseRank))
                .getPartition(knowledgeBase, query, isMinimalRelevantClosure);

        PartitionService justificationPartitionService = new PartitionUsingComputeAllJustificationImpl();
        Partition justificationPartition = justificationPartitionService.getPartition(knowledgeBase, query, isMinimalRelevantClosure);

        assertThat(justificationPartition.getRelevantPartition())
                .containsExactlyInAnyOrderElementsOf(powersetPartition.getRelevantPartition());
        assertThat(justificationPartition.getIrrelevantPartition())
                .containsExactlyInAnyOrderElementsOf(powersetPartition.getIrrelevantPartition());

        assertThat(justificationPartition.getRelevantPartition()).containsExactlyInAnyOrder(
                parser.parseFormula("(animals|~wild)"),
                parser.parseFormula("(cats|~trainable)")
        );
        assertThat(justificationPartition.getIrrelevantPartition()).containsExactlyInAnyOrder(
                parser.parseFormula("(pets=>animals)"),
                parser.parseFormula("(kittens=>cats)"),
                parser.parseFormula("(kittens|~!trainable)"),
                parser.parseFormula("(cats=>animals)"),
                parser.parseFormula("(animals|~legs)"),
                parser.parseFormula("(cats|~!wild)")
        );

        assertExposesExpandContractAndJustifications(justificationPartition);
    }

    @Test
    @DisplayName("Basic relevant partition matches PartitionUsingPowersetImpl for the kittens/cats/animals example")
    void getBasicPartitionExample2MatchesPowerset() throws Exception {
        KnowledgeBase knowledgeBase = parser.parseFormulas("(pets=>animals),(kittens=>cats), (cats|~trainable), (kittens|~!trainable), (animals|~legs), (animals|~wild), (cats=>animals), (cats|~!wild)");
        PlFormula query = parser.parseFormula("(kittens|~!wild)");
        boolean isMinimalRelevantClosure = false;
        BaseRank baseRank = new BaseRankServiceImp().constructBaseRank(knowledgeBase);

        Partition powersetPartition = new PartitionUsingPowersetImpl(fixedKbService(knowledgeBase, baseRank))
                .getPartition(knowledgeBase, query, isMinimalRelevantClosure);

        PartitionService justificationPartitionService = new PartitionUsingComputeAllJustificationImpl();
        Partition justificationPartition = justificationPartitionService.getPartition(knowledgeBase, query, isMinimalRelevantClosure);

        assertThat(justificationPartition.getRelevantPartition())
                .containsExactlyInAnyOrderElementsOf(powersetPartition.getRelevantPartition());
        assertThat(justificationPartition.getIrrelevantPartition())
                .containsExactlyInAnyOrderElementsOf(powersetPartition.getIrrelevantPartition());

        assertThat(justificationPartition.getRelevantPartition()).containsExactlyInAnyOrder(
                parser.parseFormula("(animals|~wild)"),
                parser.parseFormula("(cats|~trainable)"),
                parser.parseFormula("(kittens|~!trainable)"),
                parser.parseFormula("(cats|~!wild)")
        );
        assertThat(justificationPartition.getIrrelevantPartition()).containsExactlyInAnyOrder(
                parser.parseFormula("(pets=>animals)"),
                parser.parseFormula("(kittens=>cats)"),
                parser.parseFormula("(cats=>animals)"),
                parser.parseFormula("(animals|~legs)")
        );

        assertExposesExpandContractAndJustifications(justificationPartition);
    }

    /**
     * Structural check that the trace actually exposes expand sets, contract sets and a running
     * justifications list - the point of this implementation over PartitionUsingPowersetImpl's
     * trace, which has neither concept.
     */
    private void assertExposesExpandContractAndJustifications(Partition partition) {
        List<PartitionStep> traceSteps = partition.getTraceSteps();
        assertThat(traceSteps).isNotEmpty();

        boolean sawExpandSet = false;
        boolean sawEntailedStepWithContractSet = false;
        boolean sawJustificationsSoFar = false;

        for (int i = 0; i < traceSteps.size(); i++) {
            PartitionStep step = traceSteps.get(i);
            assertThat(step.getId()).isEqualTo(i + 1);

            if (!step.getSet().isEmpty()) {
                sawExpandSet = true;
            }
            if (step.isEntailed()) {
                assertThat(step.getMinimalSet()).isNotEmpty();
                sawEntailedStepWithContractSet = true;
            }
            if (!step.getJustificationsSoFar().isEmpty()) {
                sawJustificationsSoFar = true;
            }
        }

        assertThat(sawExpandSet).as("at least one trace step should expose a non-empty expand set").isTrue();
        assertThat(sawEntailedStepWithContractSet).as("at least one entailed trace step should expose its contract set").isTrue();
        assertThat(sawJustificationsSoFar).as("the trace should expose a running list of justifications found so far").isTrue();
    }
}
